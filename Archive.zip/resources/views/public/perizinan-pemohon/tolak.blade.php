<!-- Modal -->
<div id="showTolak" class="modal fade" role="dialog">
  <div class="modal-dialog modal-xs">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header bg-main">
        <h4 class="modal-title">Berkas Dikembalikan</h4>
        <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close" onclick="closeModal()"></button>
      </div>
      <div class="modal-body pt-4">
          <h5>Alasan Dikembalikan</h5>
          <p class="alasan_dikembalikan"></p>
          <a href="#" class="btn py-3 mt-3 btn-main w-100 text-white kirimUlang" type="button">Kirim Ulang Perizinan</a>
      </div>
      </div>

  </div>
</div>
